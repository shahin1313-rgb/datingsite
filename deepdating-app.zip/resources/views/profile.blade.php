@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Dashboard') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        <div class="card" style="width: 18rem;">
                            @if ($user->profile_picture)
                                <img src="{{ $user->profile_picture ? asset('storage/' . $user->profile_picture) : asset('images/default-profile.jpg') }}"
                                    class="card-img-top" alt="Profile Picture">
                            @else
                                <p>No profile picture available.</p>
                            @endif

                            <div class="card-body">
                                <h5 class="card-title">{{ $user->name }}</h5>
                                <h5 class="card-title">{{ $user->city }}</h5>

                                <p class="card-text">{{ $user->email }}</p>
                                <p class="card-text">{{ $user->bio }}</p>

                                <a href="#" class="btn btn-primary">show</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
