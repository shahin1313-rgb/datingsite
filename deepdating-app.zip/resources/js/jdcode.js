$(function(){
    $(".chat-list-wrapper, .message-list-wrapper").niceScroll();
})
